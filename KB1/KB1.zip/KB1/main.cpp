


/*
#define  F_CPU 11059200
#include <avr/io.h>

int main(void){
	
	DDRD = 255;
	PORTD = 0;
	
	
	while(1){
		
		
	}
	
}
*/

/*
#define F_CPU 11059200
#define kbd_port PORTA
#define d59_port PORTD

#include <avr/io.h>
#include "W:\School\ROP\INCLUDE\kbd_u.h"
#include "W:\School\ROP\INCLUDE\595_u.h"

int main(void)
{
    kb_init();
	d5_init();	
	
    while (1) 
    {
		kb_on_timer1();
		if(KB_CMD1 & 0x80)
		{
			d5_printf("%c",KB_CMD1 & 0x7F);
			KB_CMD1 = 0;
		}	
    }
}
*/

#define F_CPU 11059200
#define kbd_port PORTB

#include <avr/io.h>
#include "W:\School\ROP\INCLUDE\kbd_u.h"

int main(void){
	
	kb_init();
	DDRD = 255;
	PORTD = 255;
		
	while (1) {
		kb_on_timer1();
		if(KB_CMD1 & 0x80)
		{
			
			PORTD = 0;
			KB_CMD1 = 0;
		}
		else PORTD = 255;
	}
}